// TestPilot 脚手架：只在缺失时创建。这份归你，随便改，导出不会覆盖。
/** 从 baseUrl 猜方言。只认得出 Groq；别的都当 vLLM 一族的 OpenAI 兼容。 */
export function flavorOf(baseUrl: string, explicit?: "openai" | "groq"): "openai" | "groq" {
  if (explicit) return explicit;
  try {
    return new URL(baseUrl).hostname.endsWith("groq.com") ? "groq" : "openai";
  } catch {
    return "openai";
  }
}

