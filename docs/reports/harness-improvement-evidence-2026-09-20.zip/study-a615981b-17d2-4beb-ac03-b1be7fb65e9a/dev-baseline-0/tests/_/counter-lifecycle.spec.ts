// 由 TestPilot 生成（用例的投影）。下一次导出会覆盖它——要改就去改用例。
import { test } from "../ai";
import { checkOracle } from "../oracle";

// P1 · functional — Lifecycle contract
test("[@P1 @functional] Counter lifecycle", async ({ page, aiAction }) => {
  await page.goto(process.env.BASE_URL || "http://fixture.test/single-page");
  await aiAction("Click Increment");
  await aiAction("Click Reset counter");
  await checkOracle(page, {"kind":"text","value":"Count zero"});
  // 断言原文：Count zero
});
