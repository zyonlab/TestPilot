// TestPilot 脚手架：只在缺失时创建。这份归你，随便改，导出不会覆盖。
import type { Page } from '@playwright/test';
import { evaluateOracle, type MachineOracle, type PageSnapshot } from './oracle-core.js';
import { observeApi as observe } from './apiOracle.js';
import { sampleJudge, type JudgeAgent } from './judge.js';
export { readNumberNear } from './oracle-core.js';
export type Oracle = MachineOracle;
export const bodyText = (page: Page): Promise<string> => page.evaluate(() => document.body?.innerText ?? '');
export const observeApi = (o: Extract<Oracle,{kind:'api'}>, settle = true) => observe({...o,settleMs:settle?o.settleMs:0},{env:process.env as Record<string,string>,secrets:process.env as Record<string,string>});
export async function readBefore(page:Page, oracle:Oracle):Promise<PageSnapshot> {
 return {text:await bodyText(page),url:page.url(),...(oracle.kind==='api'?{api:await observeApi(oracle,false)}:{})};
}
export async function checkOracle(page:Page, oracle:Oracle, before?:PageSnapshot):Promise<void> {
 const after = {text:await bodyText(page),url:page.url(),...(oracle.kind==='api'?{api:await observeApi(oracle)}:{})};
 const verdict=evaluateOracle(oracle,after,before);
 if(verdict.status!=='pass') throw new Error('ORACLE_'+verdict.status.toUpperCase()+': '+verdict.detail);
}
/** judge 判据：让模型对同一屏问 samples 次，按平台内同一口径出判决。 */
export async function checkJudge(page:Page, agent:JudgeAgent, oracle:Extract<Oracle,{kind:'judge'}>):Promise<void> {
 const out=await sampleJudge(agent,oracle);
 if(out.infra) throw new Error('MODEL_UNAVAILABLE: '+(out.infraMessage??'judge sampling failed'));
 const verdict=evaluateOracle(oracle,{text:await bodyText(page),url:page.url(),judge:out.sampling});
 if(verdict.status!=='pass') throw new Error('ORACLE_'+verdict.status.toUpperCase()+': '+verdict.detail);
}
