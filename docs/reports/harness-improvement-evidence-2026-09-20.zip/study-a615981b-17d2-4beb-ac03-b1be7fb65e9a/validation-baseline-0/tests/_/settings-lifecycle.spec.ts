// 由 TestPilot 生成（用例的投影）。下一次导出会覆盖它——要改就去改用例。
import { test } from "../ai";
import { checkOracle } from "../oracle";

// P1 · functional — Lifecycle contract
test("[@P1 @functional] Settings lifecycle", async ({ page, aiAction }) => {
  await page.goto(process.env.BASE_URL || "http://fixture.test/single-page");
  await aiAction("Click Save incomplete");
  await aiAction("Click Save complete");
  await checkOracle(page, {"kind":"text","value":"Settings saved"});
  // 断言原文：Settings saved
});
