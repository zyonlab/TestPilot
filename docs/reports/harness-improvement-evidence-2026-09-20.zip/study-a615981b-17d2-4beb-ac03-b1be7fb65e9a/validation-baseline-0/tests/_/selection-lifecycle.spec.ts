// 由 TestPilot 生成（用例的投影）。下一次导出会覆盖它——要改就去改用例。
import { test } from "../ai";
import { checkOracle } from "../oracle";

// P1 · functional — Lifecycle contract
test("[@P1 @functional] Selection lifecycle", async ({ page, aiAction }) => {
  await page.goto(process.env.BASE_URL || "http://fixture.test/single-page");
  await aiAction("Click Select item");
  await aiAction("Click Clear selection");
  await checkOracle(page, {"kind":"text","value":"Nothing selected"});
  // 断言原文：Nothing selected
});
