// 由 TestPilot 生成（用例的投影）。下一次导出会覆盖它——要改就去改用例。
import { test } from "../ai";
import { checkOracle, readBefore } from "../oracle";

// P1 · functional — Lifecycle contract
test("[@P1 @functional] Validation lifecycle", async ({ page, aiAction }) => {
  await page.goto(process.env.BASE_URL || "http://fixture.test/single-page");
  const assertionBefore0 = await readBefore(page, {"kind":"text","value":"Required field error"});
  await aiAction("Click Submit empty");
  await checkOracle(page, {"kind":"text","value":"Required field error"}, assertionBefore0);
  await aiAction("Click Submit valid");
  await checkOracle(page, {"kind":"text","value":"Form saved"});
  // 断言原文：Form saved

});
